// Import functions from sales_utilities.js
import {
    initializeAutocompleteForSearch,

} from '../purchase/purchase_utilities.js';

import {
    initializeSupplierAutocomplete,
    submitSupplierForm,
    initializeAddSupplierButton,
} from '../common/utilities.js';

initializeFunctions();
function initializeFunctions() {
    // Initialize the datepicker
    $('#datepicker').datepicker({
        uiLibrary: 'bootstrap4',
        format: 'dd-mm-yyyy'
    });

    // Initialize Select2 elements
    $('.select2').select2({
        placeholder: 'Select an option', // Placeholder text
        allowClear: true, // Allow clearing the selection
    });

    $('.select2bs4').select2({
        theme: 'bootstrap4', // Use the Bootstrap 4 theme
        placeholder: 'Select an option', // Placeholder text
        allowClear: true, // Allow clearing the selection
    });

    // Call sales utilities functions
    // initializeQuantityListeners();
    initializeAutocompleteForSearch('#searchItem'); // Replace with your product search input selector
    initializeSupplierAutocomplete('#supplierName'); // Replace with your customer search input selector
    submitSupplierForm('#addSupplierForm'); // Replace with your customer form selector
    initializeAddSupplierButton(".addSupplier");
    // Additional logic or utilities
    console.log('All functions initialized!');
}


$(function () {
    // Ensure CSRF Token is set for all AJAX requests
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    // Prevent form auto-submit when scanning a barcode
    $(document).on("keydown", "#purchaseForm input[name='barcode']", function (e) {
        if (e.key === "Enter") {
            // Prevent the default behavior of the Enter key
            e.preventDefault();
        }
    });

    $(document).on("submit", "#purchaseForm", function (e) {
        e.preventDefault();

        // Get the submit button and add a spinner
        const submitButton = $(this).find("button[type='submit']");
        const spinnerText = "Processing...";
        const originalText = addSpinner(submitButton, spinnerText);

        // Serialize form data
        const formData = serializeFormToObject(this);
        let url = $("#purchaseForm").attr('action');

        // Send AJAX request
        ajaxRequest(
            url,
            "POST",
            formData,
            function (response) {
                if (response.success) {
                    const message = response.sale_type === 'new' ? 'Purchase added successfully!' : 'Purchase updated successfully!'
                    showSuccessToast(message);
                    setTimeout(function () {
                        window.location.href = response.url;
                    }, 1000);
                }

                if (response.errors) {
                    // Loop through validation errors and display them in a toaster
                    $.each(response.errors, function (field, messages) {
                        messages.forEach(function (message) {
                            showWarningToast(message); // Display each error as a toast
                        });
                    });
                }
                removeSpinner(submitButton, originalText); // Remove spinner after success
            },
            function (error) {
                if (error.responseJSON && error.responseJSON.error) {
                    const errors = error.responseJSON.error.split('<br>');
                    errors.forEach(function (err) {
                        showErrorToast(err.trim());
                    });
                } else if (error.status === 422) {
                    const validationErrors = error.responseJSON.errors;
                    $.each(validationErrors, function (field, messages) {
                        messages.forEach(function (message) {
                            showWarningToast(message); // Display each error as a toast
                        });
                    });
                } else {
                    showErrorToast("Failed to add purchase. Please try again.");
                }
                removeSpinner(submitButton, originalText);
            }
        );
    });

});
