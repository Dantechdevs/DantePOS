$(function(){
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    const url = $('#customersTable').data('url');
    loadCustomers(url)

    function loadCustomers(url) {

        $('#customersTable').DataTable({
            processing: true,
            serverSide: true,
            destroy: true, // Allow reinitialization
            ajax: {
                url: url,
                type: 'GET',
            },
            autoWidth: false, // Ensure columns adjust automatically
            responsive: true, // Make the table responsive
            order: [[0, 'desc']],
            columns: [
                {
                    data: null,
                    name: 'id',
                    title: '#',
                    className: 'text-center',
                    render: function (data, type, row, meta) {
                        return meta.row + meta.settings._iDisplayStart + 1; // Counter
                    }
                },
                { data: 'name', name: 'name', title: 'Name' },
                { data: 'mobile', name: 'mobile', title: 'Mobile', className: 'text-center' },
                { data: 'balance', name: 'balance', title: 'Balance', className: 'text-right' },
                { data: 'createdBy', name: 'createdBy', title: 'Created By' },
                { data: 'action', name: 'action', className: 'text-right', orderable: false, searchable: false, title: 'Action' },
            ],
        });
    }
})
