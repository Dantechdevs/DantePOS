import {

    initializeCustomerAutocomplete,
    submitCustomerForm,
    initializeDataTable,
    handleDeleteAction
} from '../common/utilities.js';

function initializeFunctions() {
    initializeCustomerAutocomplete('#searchCustomer'); // Replace with your customer search input selector
    submitCustomerForm("#addCustomerForm");
}

$(function () {
    // Ensure CSRF Token is set for all AJAX requests
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    const customersPaymentsListUrl = $('#customerPaymentsTable').data('url');

    initializeDataTable({
        tableSelector: '#customerPaymentsTable',
        ajaxUrl: customersPaymentsListUrl,
        columns: [
            { data: null, name: 'id', title: '#', className: 'text-center', render: (data, type, row, meta) => meta.row + meta.settings._iDisplayStart + 1 },
            { data: 'invoice_no', name: 'invoice_no', title: 'Voucher#' },
            { data: 'date', name: 'date', title: 'Date' },
            { data: 'customer', name: 'customers.name', title: 'Customer', className: 'text-left' },
            { data: 'payment_type', name: 'type', title: 'Payment Type', className: 'text-center', searchable: true },
            { data: 'amount', name: 'amount', title: 'Amount', className: 'text-right' },
            { data: 'createdBy', name: 'users.name', title: 'Created By' },
            { data: 'action', name: 'action', className: 'text-right', orderable: false, searchable: false, title: 'Action' },
        ],
    });
    // loadCustomersPayments(customersPaymentsListUrl)

    function loadCustomersPayments(url) {
        $('#customerPaymentsTable').DataTable({
            processing: true,
            serverSide: true,
            destroy: true, // Reinitialize DataTable
            ajax: {
                url: url,
                type: 'GET',
                error: function (xhr, error, thrown) {
                    console.error('Error loading data:', error); // Log errors
                },
            },
            autoWidth: false, // Disable automatic width calculations
            responsive: true, // Make table responsive
            order: [[1, 'desc']], // Default sorting by 'invoice_no'
            pageLength: 10, // Display 50 records per page
            lengthMenu: [10, 25, 50, 100, 500], // Allow the user to select records per page
            deferRender: true, // Render only visible rows to improve performance
            dom: "<'row'<'col-md-6'l><'col-md-6'f>>" + // Length menu and search
                "<'row'<'col-md-12 text-center mb-3'B>>" + // Buttons
                "<'row'<'col-md-12'tr>>" + // Table
                "<'row'<'col-md-5'i><'col-md-7'p>>", // Info and pagination
            buttons: [
                {
                    extend: 'copy',
                    text: '<i class="fas fa-copy"></i> Copy',
                    className: 'btn btn-primary btn-sm rounded-pill',
                    exportOptions: {
                        columns: ':not(:last-child)', // Exclude the last column (Action)
                    },
                },
                {
                    extend: 'excel',
                    text: '<i class="fas fa-file-excel"></i> Excel',
                    className: 'btn btn-success btn-sm rounded-pill',
                    exportOptions: {
                        columns: ':not(:last-child)', // Exclude the last column (Action)
                    },
                },
                {
                    extend: 'csv',
                    text: '<i class="fas fa-file-csv"></i> CSV',
                    className: 'btn btn-info btn-sm rounded-pill',
                    exportOptions: {
                        columns: ':not(:last-child)', // Exclude the last column (Action)
                    },
                },
                {
                    extend: 'pdf',
                    text: '<i class="fas fa-file-pdf"></i> PDF',
                    className: 'btn btn-danger btn-sm rounded-pill',
                    exportOptions: {
                        columns: ':not(:last-child)', // Exclude the last column (Action)
                    },
                    orientation: 'landscape',
                    pageSize: 'A4',
                },
                {
                    extend: 'print',
                    text: '<i class="fas fa-print"></i> Print',
                    className: 'btn btn-secondary btn-sm rounded-pill',
                    exportOptions: {
                        columns: ':not(:last-child)', // Exclude the last column (Action)
                    },
                },
            ],
            columns: [
                {
                    data: null,
                    name: 'id',
                    title: '#',
                    className: 'text-center',
                    render: function (data, type, row, meta) {
                        return meta.row + meta.settings._iDisplayStart + 1; // Add serial number
                    },
                },
                { data: 'invoice_no', name: 'invoice_no', title: 'Voucher#' },
                { data: 'date', name: 'date', title: 'Date' },
                { data: 'customer', name: 'customers.name', title: 'Customer', className: 'text-left' },
                { data: 'payment_type', name: 'type', title: 'Payment Type', className: 'text-center', searchable: true },
                { data: 'amount', name: 'amount', title: 'Amount', className: 'text-right' },
                { data: 'createdBy', name: 'users.name', title: 'Created By' },
                {
                    data: 'action',
                    name: 'action',
                    className: 'text-right',
                    orderable: false,
                    searchable: false,
                    title: 'Action'
                },
            ],
            language: {
                processing: '<i class="fas fa-spinner fa-spin"></i> Loading...', // Better processing indicator

            },
        });
    }

    $("#addCustomerPayment").on('click', function (e) {
        e.preventDefault();
        var url = $(this).attr('data-url');
        var saveCustomerPaymentUrl = $(this).attr('data-saveCustomerPaymentUrl');
        var title = "Add Customer Payment";
        console.log("URL :" + url)
        console.log("SAVE URL :" + saveCustomerPaymentUrl)
        loadCustomerPaymentForm(url, title, saveCustomerPaymentUrl)
    })

    $(document).on('click', '.editCustomerPayment', function (e) {
        e.preventDefault();
        var url = $(this).attr('data-url');
        var saveCustomerPaymentUrl = $(this).attr('data-saveCustomerPaymentUrl');
        var title = "Update Customer Payment";
        loadCustomerPaymentForm(url, title, saveCustomerPaymentUrl)
    })

    function loadCustomerPaymentForm(url, title, saveCustomerPaymentUrl) {

        ajaxRequest(
            url,
            "GET",
            {},
            function (response) {
                if (response.success) {
                    $('#customerPaymentModalContainer').html(response.html); // Add modal content to a container
                    var modal = $('#customerPaymentModal'); // get modal
                    modal.find('form').attr('action', saveCustomerPaymentUrl);
                    const modalTitle = modal.find('.modal-title');

                    // Replace the existing text node while keeping the icon intact
                    modalTitle.contents().filter(function () {
                        return this.nodeType === 3; // Node type 3 represents text nodes
                    }).remove(); // Remove the old text

                    // Add the new title after the icon
                    modalTitle.append(' ' + title);

                    // Initialize Select2
                    $('#datepicker').datepicker({
                        uiLibrary: 'bootstrap4',
                        format: 'dd-mm-yyyy'
                    });

                    // Initialize Select2 elements
                    $('.select2').select2({
                        placeholder: 'Select an option', // Placeholder text
                        allowClear: true, // Allow clearing the selection
                    });
                    if (!response.id) {
                        $('.select2').val('credit').trigger('change');
                    }


                    $('.select2bs4').select2({
                        theme: 'bootstrap4', // Use the Bootstrap 4 theme
                        placeholder: 'Select an option', // Placeholder text
                        allowClear: true, // Allow clearing the selection
                    });
                    initializeFunctions();
                    modal.modal('show')
                }
            },
            function (error) {
                showErrorToast("Failed to add customer.");
            }
        );
    }

    $(document).on("submit", "#customerPaymentForm", function (e) {
        e.preventDefault();
        console.log("form submit");

        // Get the submit button and add a spinner
        const submitButton = $(this).find("button[type='submit']");
        const spinnerText = "processing...";
        const originalText = addSpinner(submitButton, spinnerText);

        // Serialize form data
        const formData = serializeFormToObject(this);
        let url = $("#customerPaymentForm").attr('action');

        // Send AJAX request
        ajaxRequest(
            url,
            "POST",
            formData,
            function (response) {
                $('#customerPaymentsTable').DataTable().ajax.reload();
                if (response.success) {
                    $("#customerPaymentModal").modal("hide");
                    showSuccessToast(response.message);
                }

                if (response.errors) {
                    // Loop through validation errors and display them in toaster
                    $.each(response.errors, function (field, messages) {
                        messages.forEach(function (message) {
                            showWarningToast(message);
                        });
                    });
                }
                //  else {
                //     showErrorToast(response.message || "An error occurred while adding the customer.");
                // }
                removeSpinner(submitButton, originalText); // Remove spinner after success
            },
            function (error) {
                showErrorToast("Failed to add customer payment.");
                removeSpinner(submitButton, originalText); // Remove spinner after error
            }
        );
    });

    /***********************View Customer Payment *******************/
    $(document).on('click', '.view', function (e) {
        e.preventDefault();
        var url = $(this).attr('data-url');
        var title = "Customer Payment Information";
        loadCustomerPaymentInformation(url, title)
    })
    function loadCustomerPaymentInformation(url, title) {

        ajaxRequest(
            url,
            "GET",
            {},
            function (response) {
                if (response.success) {
                    $('#customerPaymentModalContainer').html(response.html); // Add modal content to a container
                    var modal = $('#viewCustomerPaymentModal'); // get modal
                    const modalTitle = modal.find('.modal-title');

                    // Replace the existing text node while keeping the icon intact
                    modalTitle.contents().filter(function () {
                        return this.nodeType === 3; // Node type 3 represents text nodes
                    }).remove(); // Remove the old text

                    // Add the new title after the icon
                    modalTitle.append(' ' + title);
                    modal.modal('show')

                }
            },
            function (error) {
                showErrorToast("Failed to load form.");
            }
        );
    }

    /***********************Delete Data **********************/

    $(document).on('click', '.delete', function (e) {
        e.preventDefault();

        const url = $(this).data('url'); // Get URL from the data attribute
        const tableId = 'customerPaymentsTable'; // ID of your DataTable

        handleDeleteAction({
            url: url,
            tableId: tableId,
            successMessage: "The record has been successfully deleted.",
            errorMessage: "Unable to delete the record. Please try again.",
            isDelete: true
        });
    });

});
