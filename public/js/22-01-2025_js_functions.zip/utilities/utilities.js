export function dynamicFormData(url, title, saveUrl, container, modalId) {
    loadForm({
        url: url,
        title: title,
        saveUrl: saveUrl,
        modalContainerId: container,
        modalId: modalId,
        triggerButtonId: "#triggerButton",
        select2Options: {
            placeholder: "-select-",
            allowClear: true,
        },
        onSuccessCallback: function (modal, response) {
            console.log("Form loaded successfully!", response);
        },
        onErrorCallback: function (response) {
            console.error("Failed to load form.", response);
        },
    });
}

export function loadForm({
    url,
    title = "",
    saveUrl = "",
    modalContainerId = "#modalContainer",
    modalId = "#dynamicModal",
    triggerButtonId = "#triggerButton",
    select2Options = { placeholder: "Select an option", allowClear: true },
    onSuccessCallback = null,
    onErrorCallback = null,
}) {
    if (typeof isLoading === "undefined") {
        window.isLoading = false;
    }

    if (!isLoading) {
        isLoading = true;
        $.ajax({
            url,
            type: "GET",
            success: function (response) {
                if (response.success) {
                    $(modalContainerId).html(response.html);

                    const modal = $(modalId);
                    const form = modal.find("form");

                    if (saveUrl) {
                        form.attr("action", saveUrl);
                    }

                    const modalTitle = modal.find(".modal-title");
                    modalTitle.contents().filter((_, node) => node.nodeType === 3).remove();
                    modalTitle.append(` ${title}`);

                    modal.modal("show");

                    modal.on("hidden.bs.modal", function () {
                        $(triggerButtonId).trigger("focus");
                    });

                    $(".select2").select2(select2Options);

                    if (typeof onSuccessCallback === "function") {
                        onSuccessCallback(modal, response);
                    }
                } else {
                    showErrorToast(response.message || "An error occurred.", "Oops!");

                    if (typeof onErrorCallback === "function") {
                        onErrorCallback(response);
                    }
                }
            },
            error: function () {
                showErrorToast("Failed to load form.", "Error!");

                if (typeof onErrorCallback === "function") {
                    onErrorCallback({ success: false });
                }
            },
            complete: function () {
                isLoading = false;
            },
        });
    }
}
/************************* Form Submit ***********************************/

export function submitForm({
    formSelector,
    method = "POST",
    reloadTableSelector = null,
    modalSelector = null,
    successToastMessage = "Operation completed successfully.",
    onSuccessCallback = null,
    onErrorCallback = null,
    beforeSendCallback = null,
    completeCallback = null,
    extraFieldUpdates = null,
    spinnerText = "Processing...",
    requestOptions = {},
}) {
    // Unbind any previous submit event handlers to avoid duplication
    $(document).off("submit", formSelector).on("submit", formSelector, function (e) {
        e.preventDefault(); // Prevent default form submission

        const form = $(this);
        const submitButton = form.find("button[type='submit']");
        const originalButtonText = submitButton.html(); // Save original button text
        const formData = serializeFormToObject(form); // Serialize the form data for AJAX
        const url = form.attr("action"); // Get the form action URL

        // Ensure the action URL is set
        if (!url) {
            console.error("Form action URL is missing.");
            showErrorToast("Form action URL is missing. Cannot submit the form.");
            return;
        }

        // Add spinner and disable the button to prevent multiple clicks
        submitButton.prop("disabled", true).html(
            `<span class="spinner-border spinner-border-sm"></span> ${spinnerText}`
        );

        // AJAX request
        $.ajax({
            url: url,
            type: method,
            data: formData,
            headers: {
                "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"), // Add CSRF token for Laravel
            },
            ...requestOptions,
            beforeSend: function () {
                if (typeof beforeSendCallback === "function") {
                    beforeSendCallback();
                }
            },
            success: function (response) {
                if (response.success) {
                    // Reload the table if specified
                    if (reloadTableSelector) {
                        $(reloadTableSelector).DataTable().ajax.reload();
                    }

                    // Hide the modal if specified
                    if (modalSelector) {
                        $(modalSelector).modal("hide");
                    }

                    // Update extra fields dynamically
                    if (typeof extraFieldUpdates === "function") {
                        extraFieldUpdates(response);
                    }

                    // Show success toast
                    showSuccessToast(response.message || successToastMessage);

                    // Execute custom success callback
                    if (typeof onSuccessCallback === "function") {
                        onSuccessCallback(response);
                    }
                } else {
                    // Handle validation or general errors
                    if (response.errors) {
                        $.each(response.errors, function (field, messages) {
                            messages.forEach(function (message) {
                                showWarningToast(message);
                            });
                        });
                    } else {
                        showErrorToast(response.message || "An error occurred.");
                    }
                }
            },
            error: function (xhr, status, error) {
                console.error("AJAX error:", xhr, status, error);
                showErrorToast("An error occurred. Please try again.");

                // Execute custom error callback
                if (typeof onErrorCallback === "function") {
                    onErrorCallback(xhr, status, error);
                }
            },
            complete: function () {
                // Restore button state after the request completes
                submitButton.prop("disabled", false).html(originalButtonText);

                if (typeof completeCallback === "function") {
                    completeCallback();
                }
            },
        });
    });
}

