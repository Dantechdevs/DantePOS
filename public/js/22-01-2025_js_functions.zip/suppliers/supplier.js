

import {
    loadSupplierForm,
    initializeAddSupplierButton,
    initializeDataTable,
    handleDeleteAction,
    submitSupplierForm
} from '../common/utilities.js';

submitSupplierForm('#addSupplierForm'); // Replace with your customer form selector
initializeAddSupplierButton(".addSupplier");
$(function () {
    // Ensure CSRF Token is set for all AJAX requests
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    const suppliersListUrl = $('#suppliersTable').data('url');

    initializeDataTable({
        tableSelector: '#suppliersTable',
        ajaxUrl: suppliersListUrl,
        columns: [
            { data: null, name: 'id', title: '#', className: 'text-center', render: (data, type, row, meta) => meta.row + meta.settings._iDisplayStart + 1 },
            { data: 'name', name: 'name', title: 'Name' },
            { data: 'mobile', name: 'mobile', title: 'Mobile', className: 'text-center' },
            { data: 'balance', name: 'balance', title: 'Balance', className: 'text-right' },
            { data: 'createdBy', name: 'user.name', title: 'Created By' },
            { data: 'action', name: 'action', className: 'text-right', orderable: false, searchable: false, title: 'Action' },
        ],
    });


    $(document).on('click', '.editSupplier', function (e) {
        e.preventDefault();
        var url = $(this).attr('data-url');
        var saveSupplierUrl = $(this).attr('data-saveSupplierUrl');
        var title = "Update Customer";
        loadSupplierForm(url, title, saveSupplierUrl)
    })


    /***********************View Customer  *******************/
    $(document).on('click', '.view', function (e) {
        e.preventDefault();
        var url = $(this).attr('data-url');
        var title = "Customer Information";
        loadSupplierInformation(url, title)
    })
    function loadSupplierInformation(url, title) {

        ajaxRequest(
            url,
            "GET",
            {},
            function (response) {
                if (response.success) {
                    $('#supplierModalContainer').html(response.html); // Add modal content to a container
                    var modal = $('#viewSupllierModal'); // get modal
                    const modalTitle = modal.find('.modal-title');

                    // Replace the existing text node while keeping the icon intact
                    modalTitle.contents().filter(function () {
                        return this.nodeType === 3; // Node type 3 represents text nodes
                    }).remove(); // Remove the old text

                    // Add the new title after the icon
                    modalTitle.append(' ' + title);
                    modal.modal('show')

                }
            },
            function (error) {
                showErrorToast("Failed to load form.");
            }
        );
    }

    /***********************Delete Data **********************/

    $(document).on('click', '.delete', function (e) {
        e.preventDefault();

        const url = $(this).data('url'); // Get URL from the data attribute
        const tableId = 'suppliersTable'; // ID of your DataTable

        handleDeleteAction({
            url: url,
            tableId: tableId,
            successMessage: "The record has been successfully deleted.",
            errorMessage: "Unable to delete the record. Please try again.",
            isDelete: true
        });
    });

});
