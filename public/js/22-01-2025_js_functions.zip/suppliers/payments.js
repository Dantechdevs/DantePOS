import {

    initializeSupplierAutocomplete,
    submitSupplierForm,
    initializeDataTable,
    handleDeleteAction
} from '../common/utilities.js';

function initializeFunctions() {
    initializeSupplierAutocomplete('#supplierName'); // Replace with your customer search input selector
    submitSupplierForm("#addSupplierForm");
}

$(function () {
    // Ensure CSRF Token is set for all AJAX requests
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    const customersPaymentsListUrl = $('#supplierPaymentsTable').data('url');

    initializeDataTable({
        tableSelector: '#supplierPaymentsTable',
        ajaxUrl: customersPaymentsListUrl,
        columns: [
            { data: null, name: 'id', title: '#', className: 'text-center', render: (data, type, row, meta) => meta.row + meta.settings._iDisplayStart + 1 },
            { data: 'purchase_no', name: 'purchase_no', title: 'Voucher#' },
            { data: 'date', name: 'date', title: 'Date' },
            { data: 'supplier', name: 'supplier.name', title: 'Supplier', className: 'text-left' },
            { data: 'amount', name: 'amount', title: 'Amount', className: 'text-right' },
            { data: 'createdBy', name: 'users.name', title: 'Created By' },
            { data: 'action', name: 'action', className: 'text-right', orderable: false, searchable: false, title: 'Action' },
        ],
    });


    $("#addSupplierPayment").on('click', function (e) {
        e.preventDefault();
        var url = $(this).attr('data-url');
        var saveSupplierPaymentUrl = $(this).attr('data-saveSupplierPaymentUrl');
        var title = "Add Supplier Payment";
        console.log("URL :" + url)
        console.log("SAVE URL :" + saveSupplierPaymentUrl)
        loadSupplierPaymentForm(url, title, saveSupplierPaymentUrl)
    })

    $(document).on('click', '.editSupplierPayment', function (e) {
        e.preventDefault();
        var url = $(this).attr('data-url');
        var saveSupplierPaymentUrl = $(this).attr('data-saveSupplierPaymentUrl');
        var title = "Update Supplier Payment";
        loadSupplierPaymentForm(url, title, saveSupplierPaymentUrl)
    })

    function loadSupplierPaymentForm(url, title, saveSupplierPaymentUrl) {

        ajaxRequest(
            url,
            "GET",
            {},
            function (response) {
                if (response.success) {
                    $('#supplierPaymentModalContainer').html(response.html); // Add modal content to a container
                    var modal = $('#supplierPaymentModal'); // get modal
                    modal.find('form').attr('action', saveSupplierPaymentUrl);
                    const modalTitle = modal.find('.modal-title');

                    // Replace the existing text node while keeping the icon intact
                    modalTitle.contents().filter(function () {
                        return this.nodeType === 3; // Node type 3 represents text nodes
                    }).remove(); // Remove the old text

                    // Add the new title after the icon
                    modalTitle.append(' ' + title);

                    // Initialize Select2
                    $('#datepicker').datepicker({
                        uiLibrary: 'bootstrap4',
                        format: 'dd-mm-yyyy'
                    });

                    // Initialize Select2 elements
                    $('.select2').select2({
                        placeholder: 'Select an option', // Placeholder text
                        allowClear: true, // Allow clearing the selection
                    });
                    if (!response.id) {
                        $('.select2').val('credit').trigger('change');
                    }


                    $('.select2bs4').select2({
                        theme: 'bootstrap4', // Use the Bootstrap 4 theme
                        placeholder: 'Select an option', // Placeholder text
                        allowClear: true, // Allow clearing the selection
                    });
                    initializeFunctions();
                    modal.modal('show')
                }
            },
            function (error) {
                showErrorToast("Failed to add customer.");
            }
        );
    }

    $(document).on("submit", "#supplierPaymentForm", function (e) {
        e.preventDefault();
        console.log("form submit");

        // Get the submit button and add a spinner
        const submitButton = $(this).find("button[type='submit']");
        const spinnerText = "processing...";
        const originalText = addSpinner(submitButton, spinnerText);

        // Serialize form data
        const formData = serializeFormToObject(this);
        let url = $("#supplierPaymentForm").attr('action');

        // Send AJAX request
        ajaxRequest(
            url,
            "POST",
            formData,
            function (response) {
                $('#supplierPaymentsTable').DataTable().ajax.reload();
                if (response.success) {
                    $("#supplierPaymentModal").modal("hide");
                    showSuccessToast(response.message);
                }

                if (response.errors) {
                    // Loop through validation errors and display them in toaster
                    $.each(response.errors, function (field, messages) {
                        messages.forEach(function (message) {
                            showWarningToast(message);
                        });
                    });
                }
                //  else {
                //     showErrorToast(response.message || "An error occurred while adding the customer.");
                // }
                removeSpinner(submitButton, originalText); // Remove spinner after success
            },
            function (error) {
                showErrorToast("Failed to add customer payment.");
                removeSpinner(submitButton, originalText); // Remove spinner after error
            }
        );
    });

    /***********************View Supplier Payment *******************/
    $(document).on('click', '.view', function (e) {
        e.preventDefault();
        var url = $(this).attr('data-url');
        var title = "Supplier Payment Information";
        loadSupplierPaymentInformation(url, title)
    })
    function loadSupplierPaymentInformation(url, title) {

        ajaxRequest(
            url,
            "GET",
            {},
            function (response) {
                if (response.success) {
                    $('#supplierPaymentModalContainer').html(response.html); // Add modal content to a container
                    var modal = $('#viewSupplierPaymentModal'); // get modal
                    const modalTitle = modal.find('.modal-title');

                    // Replace the existing text node while keeping the icon intact
                    modalTitle.contents().filter(function () {
                        return this.nodeType === 3; // Node type 3 represents text nodes
                    }).remove(); // Remove the old text

                    // Add the new title after the icon
                    modalTitle.append(' ' + title);
                    modal.modal('show')

                }
            },
            function (error) {
                showErrorToast("Failed to load form.");
            }
        );
    }

    /***********************Delete Data **********************/

    $(document).on('click', '.delete', function (e) {
        e.preventDefault();

        const url = $(this).data('url'); // Get URL from the data attribute
        const tableId = 'supplierPaymentsTable'; // ID of your DataTable

        handleDeleteAction({
            url: url,
            tableId: tableId,
            successMessage: "The record has been successfully deleted.",
            errorMessage: "Unable to delete the record. Please try again.",
            isDelete: true
        });
    });

});
