// Import functions from sales_utilities.js
import {
    initializeAutocompleteForSearch,
} from '../common/sales_utilities.js';

import {
    initializeCustomerAutocomplete,
    submitCustomerForm,
    // initializeAddCustomerButton,
} from '../common/utilities.js';
import { submitForm } from '../utilities/utilities.js';
initializeFunctions();

function initializeFunctions() {
    // Initialize the datepicker
    $('#datepicker').datepicker({
        uiLibrary: 'bootstrap4',
        format: 'dd-mm-yyyy',
    });

    // Initialize Select2 elements
    $('.select2').select2({
        placeholder: 'Select an option', // Placeholder text
        allowClear: true, // Allow clearing the selection
    });

    $('.select2bs4').select2({
        theme: 'bootstrap4', // Use the Bootstrap 4 theme
        placeholder: 'Select an option', // Placeholder text
        allowClear: true, // Allow clearing the selection
    });

    // Call sales utilities functions
    initializeAutocompleteForSearch('#searchItem'); // Replace with your product search input selector
    initializeCustomerAutocomplete('#searchCustomer'); // Replace with your customer search input selector
    // submitCustomerForm('#addCustomerForm'); // Replace with your customer form selector
    // initializeAddCustomerButton(".addCustomer");

    console.log('All functions initialized!');
}

$(function () {
    // Ensure CSRF Token is set for all AJAX requests
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
        },
    });



    // Prevent form auto-submit when scanning a barcode
    $(document).on("keydown", "#saleForm input[name='barcode']", function (e) {
        if (e.key === "Enter") {
            // Prevent the default behavior of the Enter key
            e.preventDefault();
        }
    });

    $(document).on("submit", "#saleForm", function (e) {
        e.preventDefault();

        // Get the submit button and add a spinner
        const submitButton = $(this).find("button[type='submit']");
        const spinnerText = "Processing...";
        const originalText = addSpinner(submitButton, spinnerText);

        // Serialize form data
        const formData = serializeFormToObject(this);
        let url = $("#saleForm").attr('action');

        // Send AJAX request
        ajaxRequest(
            url,
            "POST",
            formData,
            function (response) {
                if (response.success) {
                    if (response.sale_type === 'new') {
                        showSuccessToast("Sale added successfully!");

                        var saleUrl = '/add-sale';
                        var renderCurrentForm = '.renderSalesForm';
                        reloadFormComponent(saleUrl, renderCurrentForm);
                        const windowFeatures = "scrollbars=yes,resizable=yes,height=500,width=500";
                        window.open(response.url, "_blank", windowFeatures);
                    } else if (response.sale_type === 'update') {
                        showSuccessToast("Sale updated successfully!");
                        setTimeout(function () {
                            window.location.href = response.url;
                        }, 1000);
                    }
                }

                if (response.errors) {
                    // Loop through validation errors and display them in a toaster
                    $.each(response.errors, function (field, messages) {
                        messages.forEach(function (message) {
                            showWarningToast(message); // Display each error as a toast
                        });
                    });
                }

                removeSpinner(submitButton, originalText); // Remove spinner after success
            },
            function (error) {
                if (error.responseJSON && error.responseJSON.error) {
                    const errors = error.responseJSON.error.split('<br>');
                    errors.forEach(function (err) {
                        showErrorToast(err.trim());
                    });
                } else if (error.status === 422) {
                    const validationErrors = error.responseJSON.errors;
                    $.each(validationErrors, function (field, messages) {
                        messages.forEach(function (message) {
                            showWarningToast(message); // Display each error as a toast
                        });
                    });
                } else {
                    showErrorToast("Failed to add sale. Please try again.");
                }
                removeSpinner(submitButton, originalText);
            }
        );
    });

    function reloadFormComponent(url, renderCurrentForm) {
        $.ajax({
            url: url,
            type: 'GET',
            success: function (response) {
                if (response.html) {
                    $(renderCurrentForm).html(response.html);

                    // Remove previous assets
                    $('link[href^="css/"]').remove();
                    $('script[src^="js/"]').remove();

                    // Load new assets
                    let scriptsToLoad = response.scripts || [];
                    let stylesToLoad = response.styles || [];

                    // Load CSS files
                    stylesToLoad.forEach((styleUrl) => loadCSS(styleUrl));

                    // Load JS files
                    if (scriptsToLoad.length) {
                        let scriptsLoaded = 0;
                        scriptsToLoad.forEach((scriptUrl) => {
                            loadScript(scriptUrl.url, function () {
                                scriptsLoaded++;
                                if (scriptsLoaded === scriptsToLoad.length) {
                                    // All scripts loaded, initialize functions
                                    initializeFunctions();
                                }
                            }, scriptUrl.isModule);
                        });
                    } else {
                        // No scripts to load, initialize functions directly
                        initializeFunctions();
                    }
                }
            },
            error: function (xhr, status, error) {
                console.error('Error reloading form:', error);
                alert('Failed to reload form view.');
            },
        });
    }

    function loadCSS(url) {
        if (!$("link[href='" + url + "']").length) {
            const link = document.createElement('link');
            link.rel = 'stylesheet';
            link.href = url;
            document.head.appendChild(link);
        }
    }

    function loadScript(url, callback, isModule = false) {
        if (!$("script[src='" + url + "']").length) {
            const script = document.createElement('script');
            script.src = url;

            // Set type to module or regular script
            script.type = isModule ? 'module' : 'text/javascript';

            script.onload = () => callback && callback();
            script.onerror = () => console.error(`Failed to load script: ${url}`);

            document.head.appendChild(script);
        } else {
            if (callback) {
                callback();
            }
        }
    }
});
