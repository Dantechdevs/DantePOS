<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>{{ $saleInvoice['customers']['name'] ?? '' }} - Sale Invoice</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            font-size: 12px;
            color: #333;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
        }

        .container {
            width: 210mm;
            /* A5 width */
            max-width: 210mm;
            margin: 10mm auto;
            /* Center the content */
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ddd;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #ddd;
        }

        .header .logo img {
            max-width: 100px;
        }

        .header .title {
            text-align: center;
            flex-grow: 1;
        }

        .header .title h1 {
            font-size: 18px;
            font-weight: bold;
            margin: 0;
        }

        .header .title p {
            font-size: 12px;
            margin: 0;
            color: #666;
        }

        .details-row {
            margin-bottom: 20px;
        }

        .details-row p {
            margin: 3px 0;
        }

        .details-row strong {
            font-weight: bold;
        }

        .invoice-details {
            margin-bottom: 20px;
            font-size: 12px;
            line-height: 1.2;
        }

        .invoice-details p {
            margin: 0;
        }

        .table {
            font-size: 12px;
        }

        .table th,
        .table td {
            padding: 8px;
            vertical-align: middle;
        }

        .table th {
            background-color: #f2f2f2;
        }

        .totals-row {
            font-weight: bold;
        }

        .totals {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .totals .qr-code {
            margin-right: 20px;
        }

        footer {
            margin-top: 20px;
            text-align: center;
            font-size: 10px;
            color: #666;
        }

        @media print {
            body {
                margin-left: 10mm;
                background-color: #fff;
            }

            .container {
                border: none;
                box-shadow: none;
            }

            footer {
                position: fixed;
                bottom: 0;
                width: 100%;
                text-align: center;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <div class="logo">
                <img src="{{ optional($settings)['invoice_logo'] && file_exists(public_path(optional($settings)['invoice_logo']))
                    ? asset(optional($settings)['invoice_logo'])
                    : (optional($settings)['default_image'] && file_exists(public_path(optional($settings)['default_image']))
                        ? asset(optional($settings)['default_image'])
                        : asset('images/default-image.png')) }}"
                    alt="Logo">
            </div>

            <div class="title">
                <h1>INVOICE</h1>
                <p>{{ optional($settings)['site_name'] }}, {{ optional($settings)['site_address'] }} <br>
                    {{ $settings['mobile_numbers'] }}
                </p>

            </div>
        </div>

        <!-- Company and Customer Details -->
        <!-- Invoice Details -->
        <div class="invoice-details">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <!-- Left Section: Invoice Number and Date -->
                <div>
                    <p><strong>Invoice #:</strong> {{ $saleInvoice['invoice_no'] }}</p>
                    <p><strong>Date:</strong> {{ date('d/m/Y | h:i A', strtotime($saleInvoice['date'])) }}</p>
                    <p><strong>Status:</strong>
                        {{ $saleInvoice['status'] == 0
                            ? 'Canceled'
                            : ($saleInvoice['status'] == 1
                                ? 'Billed'
                                : ($saleInvoice['status'] == 2
                                    ? 'Pending'
                                    : ($saleInvoice['status'] == 3
                                        ? 'Return'
                                        : 'Unknown'))) }}
                    </p>
                </div>

                <!-- Right Section: Customer Details -->
                <div style="text-align: right;">
                    <p><strong>Customer:</strong> {{ optional($saleInvoice['customers'])['name'] }}</p>
                    <p><strong>Phone:</strong> {{ optional($saleInvoice['customers'])['mobile'] }}</p>
                    <address><strong>Phone:</strong> {{ optional($saleInvoice['customers'])['address'] }}</address>
                </div>
            </div>
        </div>


        <!-- Invoice Details -->
        {{-- <div class="invoice-details">
            <p><strong>Invoice #:</strong> SN-{{ $saleInvoice['invoice_no'] }}</p>
            <p><strong>Date:</strong> {{ date('M d, Y', strtotime($saleInvoice['date'])) }}</p>
            <p><strong>Status:</strong> {{ $saleInvoice['status'] == 1 ? 'Confirmed' : 'Canceled' }}</p>
        </div> --}}

        <!-- Products Table -->
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Product</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>Item Total</th>
                </tr>
            </thead>
            <tbody>
                @php $counter = 0; @endphp
                @foreach ($saleitmesAddons as $addons)
                    @php
                        $counter = $counter + 1;
                        $product = \App\Models\Product::select('id', 'qtyPerUnit')->find($addons['product_id']);
                        $result = \App\Http\Helpers\ProductHelper::calculateSoldAndRemaining(
                            $addons['quantity'],
                            $product['qtyPerUnit'],
                        );
                    @endphp
                    <tr>
                        <td>{{ $counter }}</td>
                        <td>{{ $addons['productName'] }}</td>
                        <td style="text-align: center;">
                            @if ($result['boxes_sold'] > 0)
                                {{ $result['boxes_sold'] }} {{ $addons['unit'] }}
                            @endif
                            @if ($result['boxes_sold'] > 0 && $result['items_sold'] > 0)
                                ,
                            @endif
                            @if ($result['items_sold'] > 0)
                                {{ $result['items_sold'] }} pieces
                            @endif
                        </td>
                        <td style="text-align: right;">{{ number_format($addons['selling_price']) }}</td>
                        <td style="text-align: right;">{{ number_format($addons['amount']) }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>

        <!-- Totals and QR Code -->
        <div class="totals">
            <div class="qr-code">
                @php
                    $url = route('print.invoice', $saleInvoice['invoice_no']);
                @endphp
                <img src="https://api.qrserver.com/v1/create-qr-code/?size=60x60&data={{ urlencode($url) }}"
                    alt="QR Code">
            </div>
            <div>
                <table style="width: 100%; margin-top: 10px;">
                    <tbody>
                        @if ($saleInvoice['sub_total'] > 0)
                            <tr>
                                <td style="text-align: left;"><strong>Sub Total:</strong></td>
                                <td style="text-align: right;">{{ number_format($saleInvoice['sub_total']) }}</td>
                            </tr>
                        @endif
                        @if ($saleInvoice['other_charges'] > 0)
                            <tr>
                                <td style="text-align: left;"><strong>Other Charges:</strong></td>
                                <td style="text-align: right;">{{ number_format($saleInvoice['other_charges']) }}</td>
                            </tr>
                        @endif
                        @if ($saleInvoice['discount'] > 0)
                            <tr>
                                <td style="text-align: left;">
                                    <strong>Discount:</strong>
                                    @if (isset($saleInvoice['discount_type']))
                                        ({{ ucfirst($saleInvoice['discount_type']) }})
                                    @endif
                                </td>
                                <td style="text-align: right;">
                                    @if (isset($saleInvoice['discount_type']) && $saleInvoice['discount_type'] === 'percentage')
                                        ({{ number_format($saleInvoice['discount']) }}%)
                                        {{ number_format($saleInvoice['discount_amount']) }}
                                    @else
                                        {{ number_format($saleInvoice['discount']) }}
                                    @endif
                                </td>
                            </tr>
                        @endif
                        <tr>
                            <td style="text-align: left;"><strong>Grand Total:</strong></td>
                            <td style="text-align: right;">{{optional($settings)['currency']}} {{ number_format($saleInvoice['grand_total']) }}</td>
                        </tr>
                        @if ($customerBalance > 0)
                            @php
                                $previousBalance = 0;
                                // $previousBalance = $customerBalance - $saleInvoice['grand_total'];
                                $status = $customerBalance['status'] ?? null; // Ensure 'status' exists
                                $previousBalance =
                                    $status === 1
                                        ? $customerBalance - $saleInvoice['grand_total']
                                        : $customerBalance - $saleInvoice['grand_total'];
                            @endphp

                            <tr>
                                <td style="text-align: left;"><strong>Previous Balance:</strong></td>
                                <td style="text-align: right;">
                                    {{ $previousBalance < 0 ? -1 * $previousBalance . ' CR' : $previousBalance . ' DB' }}
                                </td>
                            </tr>


                            <tr>
                                <td style="text-align: left;"><strong>Total Balance:</strong></td>
                                <td style="text-align: right;">
                                    {{ optional($settings)['currency'] }}
                                    {{ $customerBalance < 0 ? -1 * $customerBalance . ' CR' : $customerBalance . ' DB' }}
                                </td>
                            </tr>
                        @endif
                    </tbody>
                </table>
            </div>

        </div>
        @if ($saleInvoice['description'])
            <div>
                <span><b>Note:</b></span>
                <p>
                    {{ $saleInvoice['description'] }}
                </p>
            </div>
        @endif

        <!-- Footer -->
        <footer>
            <p>{{ optional($settings)['footer_text'] }}</p>
        </footer>
    </div>
    <script>
        window.addEventListener('load', function() {
            window.print();
        });
    </script>
</body>

</html>
