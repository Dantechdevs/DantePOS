<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thermal Invoice</title>
    <style>
        body {
            width: 78mm;
            /* Increased width slightly to fill more space */
            margin: 0 auto;
            /* Center the content */
            font-family: Arial, sans-serif;
            font-size: 13px;
            /* Ensure clear font size */
            color: #000;
            background-color: #fff;
        }

        .container {
            padding: 2mm;
            /* Maintain small padding to reduce unused space */
            box-sizing: border-box;
        }

        .header {
            text-align: center;
            margin-bottom: 5px;
        }

        .header img {
            max-width: 120px;
            /* Adjusted logo size */
            max-height: 120px;
            /* Adjusted logo size */
            margin-bottom: 5px;
        }

        .header h1 {
            font-size: 14px;
            margin: 0;
        }

        .header p {
            font-size: 10px;
            /* Slightly larger for better readability */
            margin: 1px 0;
        }

        .details {
            margin-bottom: 5px;
        }

        .details-row {
            display: flex;
            justify-content: space-between;
        }

        .details-left,
        .details-right {
            width: 50%;
            box-sizing: border-box;
        }

        .details-left {
            text-align: left;
        }

        .details-right {
            text-align: right;
        }

        .details p {
            margin: 1px 0;
        }

        table {
            width: 100%;
            /* Full width to utilize the available space */
            border-collapse: collapse;
            margin-bottom: 5px;
        }

        table th,
        table td {
            padding: 2px 3px;
            /* Compact padding */
            border: 1px dotted #000;
            font-size: 11px;
            word-wrap: break-word;
            /* Prevent text overflow */
            text-align: left;
        }

        table th {
            background-color: #f2f2f2;
            font-weight: bold;
        }

        .totals {
            text-align: right;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .totals .qr-code {
            display: inline-block;
            margin-right: 5px;
        }

        .totals .summary {
            word-wrap: break-word;
            margin-right: 2px;
            /* Adjusted margin to reduce extra space */
        }

        footer {
            text-align: center;
            font-size: 10px;
            /* Slightly larger footer */
            margin-top: 5px;
        }

        .qr-code img {
            max-width: 50px;
            /* Compact QR code size */
        }

        @media print {
            body {
                margin: 0;
                width: 78mm;
                /* Optimized for printing */
            }

            .container {
                padding: 2mm;
                /* Consistent print padding */
            }

            footer {
                margin-top: 0;
                position: relative;
                text-align: center;
                font-size: 10px;
            }
        }
    </style>



</head>

<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <img src="{{ optional($settings)['invoice_logo'] && file_exists(public_path(optional($settings)['invoice_logo']))
                ? asset(optional($settings)['invoice_logo'])
                : (optional($settings)['default_image'] && file_exists(public_path(optional($settings)['default_image']))
                    ? asset(optional($settings)['default_image'])
                    : asset('images/default-image.png')) }}"
                alt="Logo">
            <h1>{{ optional($settings)['site_name'] }}</h1>
            <p>{{ optional($settings)['site_address'] }}</p>
            <p>{{ optional($settings)['mobile_numbers'] }}</p>
        </div>

        <!-- Invoice Details -->
        <div class="details">
            <div class="details-row" style="display: flex; justify-content: space-between;">
                <!-- Left Section -->
                <div class="details-left">
                    <p><strong>Invoice #:</strong> {{ $saleInvoice['invoice_no'] }}</p>
                    <p><strong>Date:</strong> {{ date('d/m/Y | h:i A', strtotime($saleInvoice['date'])) }}</p>
                    <p><strong>Status:</strong>
                        {{ $saleInvoice['status'] == 0
                            ? 'Canceled'
                            : ($saleInvoice['status'] == 1
                                ? 'Billed'
                                : ($saleInvoice['status'] == 2
                                    ? 'Pending'
                                    : ($saleInvoice['status'] == 3
                                        ? 'Return'
                                        : 'Unknown'))) }}
                    </p>
                </div>

                <!-- Right Section -->
                <div class="details-right" style="text-align: right;">
                    @if (@$saleInvoice['customers'] && !empty(@$saleInvoice['customers']['name']))
                        <p><strong>Customer Name:</strong> {{ optional($saleInvoice['customers'])['name'] ?? 'N/A' }}
                        </p>
                    @endif
                    @if (@$saleInvoice['customers'] && !empty(@$saleInvoice['customers']['mobile']))
                        <p><strong>Mobile:</strong> {{ optional($saleInvoice['customers'])['mobile'] ?? 'N/A' }}</p>
                    @endif
                    @if (@$saleInvoice['customers'] && !empty(@$saleInvoice['customers']['address']))
                        <p><strong>Address:</strong> {{ optional($saleInvoice['customers'])['address'] ?? 'N/A' }}</p>
                    @endif

                </div>
            </div>
        </div>


        <!-- Products Table -->
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Product</th>
                    <th>Qty</th>
                    <th>Price</th>
                    <th>Item Total</th>
                </tr>
            </thead>
            <tbody>
                @php $counter = 0; @endphp
                @foreach ($saleitmesAddons as $addons)
                    @php
                        $counter = $counter + 1;
                        $product = \App\Models\Product::select('id', 'qtyPerUnit')->find($addons['product_id']);
                        $result = \App\Http\Helpers\ProductHelper::calculateSoldAndRemaining(
                            $addons['quantity'],
                            $product['qtyPerUnit'],
                        );
                    @endphp
                    <tr>
                        <td>{{ $counter }}</td>
                        <td>{{ $addons['productName'] }}</td>
                        <td style="text-align: center;">
                            @if ($result['boxes_sold'] > 0)
                                {{ $result['boxes_sold'] }} {{ $addons['unit'] }}
                            @endif
                            @if ($result['boxes_sold'] > 0 && $result['items_sold'] > 0)
                                ,
                            @endif
                            @if ($result['items_sold'] > 0)
                                {{ $result['items_sold'] }} pieces
                            @endif
                        </td>
                        <td style="text-align: right;">{{ number_format($addons['selling_price']) }}</td>
                        <td style="text-align: right;">{{ number_format($addons['amount']) }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>

        <!-- Totals and QR Code -->
        <div class="totals">
            <div class="qr-code">
                @php
                    $url = route('print.invoice', $saleInvoice['invoice_no']);
                @endphp
                <img src="https://api.qrserver.com/v1/create-qr-code/?size=60x60&data={{ urlencode($url) }}"
                    alt="QR Code">
            </div>
            <div class="summary">
                @if ($saleInvoice['sub_total'] > 0)
                    <p><strong>Sub Total:</strong> {{ number_format($saleInvoice['sub_total']) }}</p>
                @endif

                @if ($saleInvoice['other_charges'] > 0)
                    <p><strong>Other Charges:</strong> {{ number_format($saleInvoice['other_charges']) }}</p>
                @endif

                @if ($saleInvoice['discount'] > 0)
                    <p>
                        <strong>Discount: ({{ ucfirst($saleInvoice['discount_type']) }})</strong>
                        @if ($saleInvoice['discount_type'] === 'percentage')
                            ({{ $saleInvoice['discount'] }}% ) {{ number_format($saleInvoice['discount_amount']) }}
                        @else
                            {{ number_format($saleInvoice['discount']) }}
                        @endif
                    </p>
                @endif



                <p><strong>Grand Total:</strong> {{optional($settings)['currency']}} {{ number_format($saleInvoice['grand_total']) }}</p>
                @if ($customerBalance > 0)
                    @php
                        $previousBalance = $customerBalance - $saleInvoice['grand_total'];
                    @endphp
                    @if ($previousBalance > 0)
                        <p><strong>Previous Balance:</strong>
                            {{ $previousBalance < 0 ? -1 * $previousBalance . ' CR' : $previousBalance . ' DB' }}
                        </p>
                    @endif
                    <p><strong>Total Balance:</strong>
                        {{optional($settings)['currency']}} {{ $customerBalance < 0 ? -1 * $customerBalance . ' CR' : $customerBalance . ' DB' }}
                    </p>
                @endif
            </div>
        </div>
        @if ($saleInvoice['description'])
            <div>
                <span>Note:</span>
                <p>
                    {{ $saleInvoice['description'] }}
                </p>
            </div>
        @endif

        <!-- Footer -->
        <footer>
            <p>{{ optional($settings)['footer_text'] }}</p>
        </footer>
    </div>

    <script>
        window.onload = function() {
            window.print();
        };
    </script>
</body>

</html>
